import smtplib
import os
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart

COMMASPACE = ', '
path = os.path.dirname( os.path.abspath(__file__) )

# Define params
rrdpath = f'{path}/../RRD/'
imgpath = f'{path}/../IMG/'
fname = 'trend.rrd'

mailsender = "testSender@example.com"
mailreceip = "testRecv@example.com"
mailserver = 'mail.smtpbucket.com'
password = 'dvduuffmlhspbmjj'

def send_alert_attached(subject):
    """ Envía un correo electrónico adjuntando la imagen en IMG
    """
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = mailsender
    msg['To'] = mailreceip
    fp = open(imgpath+'deteccion.png', 'rb')
    img = MIMEImage(fp.read())
    fp.close()
    msg.attach(img)
    s = smtplib.SMTP(mailserver, port="8025")

    # s.starttls()
    # Login Credentials for sending the mail
    # s.login(mailsender, password)

    s.sendmail(mailsender, mailreceip, msg.as_string())
    s.quit()