import time
import rrdtool
from getSNMP import consultaSNMP
import os
path = os.path.dirname( os.path.abspath(__file__) )

rrdpath = f'{path}/../RRD/'
carga_CPU = 0

while 1:
    rrdtool.dump( rrdpath+'trend.rrd', rrdpath + "trend.xml")
    # Los núcleos del procesador están numerados del 1966_08 al 1966_15 (al menos para los Intel Core i-7)
    carga_CPU_core_1 = int(consultaSNMP('comunidadSNMP','localhost','1.3.6.1.2.1.25.3.3.1.2.196608'))
    carga_CPU_core_2 = int(consultaSNMP('comunidadSNMP','localhost','1.3.6.1.2.1.25.3.3.1.2.196609'))
    carga_CPU_core_3 = int(consultaSNMP('comunidadSNMP','localhost','1.3.6.1.2.1.25.3.3.1.2.196610'))
    carga_CPU_core_4 = int(consultaSNMP('comunidadSNMP','localhost','1.3.6.1.2.1.25.3.3.1.2.196611'))
    valor = f"N:{carga_CPU_core_1}:{carga_CPU_core_2}:{carga_CPU_core_3}:{carga_CPU_core_4}"
    print (valor)
    rrdtool.update(rrdpath+'trend.rrd', valor)
    rrdtool.dump( rrdpath+'trend.rrd', rrdpath + "trend.xml")
    time.sleep(5)

if ret:
    print (rrdtool.error())
    time.sleep(300)
