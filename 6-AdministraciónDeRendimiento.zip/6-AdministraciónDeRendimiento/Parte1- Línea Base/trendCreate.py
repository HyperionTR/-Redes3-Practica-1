import rrdtool
import os
path = os.path.dirname( os.path.abspath(__file__) )

ret = rrdtool.create(f"{path}/../RRD/trend.rrd",
                     "--start",'N',
                     "--step",'5',
                     "DS:CPUcore1:GAUGE:120:0:100",
                     "DS:CPUcore2:GAUGE:120:0:100",
                     "DS:CPUcore3:GAUGE:120:0:100",
                     "DS:CPUcore4:GAUGE:120:0:100",
                     "RRA:AVERAGE:0.5:1:100",
                     "RRA:AVERAGE:0.5:1:100",
                     "RRA:AVERAGE:0.5:1:100",
                     "RRA:AVERAGE:0.5:1:100")
if ret:
    print (rrdtool.error())
