import sys
import rrdtool
import time
import datetime
from  Notify import send_alert_attached
import time
import os

path = os.path.dirname( os.path.abspath(__file__) )

rrdpath = f'{path}/../RRD/'
imgpath = f'{path}/../IMG/'

def generarGrafica(ultima_lectura):
    tiempo_final = int(ultima_lectura)
    tiempo_inicial = tiempo_final - 60 * 3
    ret = rrdtool.graphv( imgpath+"deteccion.png",
                     "--start",str(tiempo_inicial),
                     "--end",str(tiempo_final),
                     "--vertical-label=Cpu load",
                    '--lower-limit', '0',
                    '--upper-limit', '100',
                    "--title=Carga del CPU del agente Usando SNMP y RRDtools \n Detección de umbrales",
                    "DEF:cargaCPU1="+rrdpath+"trend.rrd:CPUcore1:AVERAGE",
                    "DEF:cargaCPU2="+rrdpath+"trend.rrd:CPUcore2:AVERAGE",
                    "DEF:cargaCPU3="+rrdpath+"trend.rrd:CPUcore3:AVERAGE",
                    "DEF:cargaCPU4="+rrdpath+"trend.rrd:CPUcore4:AVERAGE",
                     
                     "VDEF:cargaMAX1=cargaCPU1,MAXIMUM",
                     "VDEF:cargaMAX2=cargaCPU2,MAXIMUM",
                     "VDEF:cargaMAX3=cargaCPU3,MAXIMUM",
                     "VDEF:cargaMAX4=cargaCPU4,MAXIMUM",

                     "VDEF:cargaMIN1=cargaCPU1,MINIMUM",
                     "VDEF:cargaMIN2=cargaCPU2,MINIMUM",
                     "VDEF:cargaMIN3=cargaCPU3,MINIMUM",
                     "VDEF:cargaMIN4=cargaCPU4,MINIMUM",

                     "CDEF:umbral50_c1=cargaCPU1,50,LT,0,cargaCPU1,IF",
                     "CDEF:umbral50_c2=cargaCPU2,50,LT,0,cargaCPU2,IF",
                     "CDEF:umbral50_c3=cargaCPU3,50,LT,0,cargaCPU3,IF",
                     "CDEF:umbral50_c4=cargaCPU4,50,LT,0,cargaCPU4,IF",
                     
                     "LINE2:cargaCPU1#00FF00:Carga del Core 1",
                     "LINE2:cargaCPU2#00CC00:Carga del Core 2",
                     "LINE2:cargaCPU3#009900:Carga del Core 3",
                     "LINE2:cargaCPU4#007700:Carga del Core 4",

                     "LINE2:umbral50_c1#FF9F00:Carga Core 1 mayor de 50",
                     "LINE2:umbral50_c2#CC9F00:Carga Core 2 mayor de 50",
                     "LINE2:umbral50_c3#999F00:Carga Core 3 mayor de 50",
                     "LINE2:umbral50_c4#779F00:Carga Core 4 mayor de 50",

                     "HRULE:50#FF0000:Umbral  50%",

                     "GPRINT:cargaMIN1:%6.2lf %SMIN",
                     "GPRINT:cargaMIN2:%6.2lf %SMIN",
                     "GPRINT:cargaMIN3:%6.2lf %SMIN",
                     "GPRINT:cargaMIN4:%6.2lf %SMIN")
    print (ret)

while (1):
    ultima_actualizacion = rrdtool.lastupdate(rrdpath + "trend.rrd")
    timestamp=ultima_actualizacion['date'].timestamp()
    dato=ultima_actualizacion['ds']["CPUcore1"]
    print(dato)
    if dato> 50:
        generarGrafica(int(timestamp))
        send_alert_attached("Sobrepasa el umbral")
        print("sobrepasa el umbral")
    time.sleep(5)